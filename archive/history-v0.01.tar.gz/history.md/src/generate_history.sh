#!/bin/bash

# Default values
PROJECT_NAME="Project Name"
NUM_COMMENTS=2
LOG_DIR="./logs/history-log.md"
CURRENT_DATE=$(date +%Y-%m-%d)  # Using current date: April 10, 2025

# Function to display help
show_help() {
    echo "Usage: $0 [options] [<project_name>] [<number_of_comments>] [<logfile_dir>]"
    echo "Options:"
    echo "  -h    Display this help message"
    echo "  -v    Verbose mode"
    echo "  -r    Read history (not implemented)"
    echo "  -l    Read log (not implemented)"
    echo "  -u    Update (not implemented)"
    echo "  -n    New create (default behavior)"
    echo "Parameters:"
    echo "  <project_name>        Name of the project (default: 'Project Name')"
    echo "  <number_of_comments>  Number of comments [0-20] (default: 2)"
    echo "  <logfile_dir>         Log file directory (default: ./logs/history-log.md)"
}

# Function to create History.md
create_history() {
    local project=$1
    local num=$2
    local log_path=$3

    # Create directory for log file if it doesn't exist
    mkdir -p "$(dirname "$log_path")"

    # Create History.md
    cat > History.md << EOF
# $project

> Summary: [Description: <shorTitle> ](log/history-logs.md#Description ) (David Mullins)
>
> \`\`\`bash
> 
> \`\`\`

[next>](#comment-1)  [Log file](log/history-logs.md)

---
EOF

    # Generate comments
    for ((i=1; i<=num; i++)); do
        cat >> History.md << EOF
## Comment $i
|[Top](#${project,,})| [<Previous](#comment-$((i-1))) |[Next>](#comment-$((i+1))) | [$CURRENT_DATE](log/logs.md#$CURRENT_DATE) |

> Summary: [History_Comment_$i](log/history-logs.md#history-comment-$i) (David Mullins)
>
> \`\`\`bash
> 
> \`\`\`
>
>  [sub-history_comment_$i](log/history-logs.md#sub-history-comment-$i) 

[Content ${i}-up](#comment-$i)

...
### subject $i

...
|[Top](#${project,,}) | [<Previous](#comment-$((i-1))) |[Next>](#comment-$((i+1)))| [References](#references) | [Footnotes](#footnotese-$i) | [Folder Attachments](./assets/comment-$i/Readme.md)|


### Footnotes $i
---
EOF
    done

    # Add References section
    cat >> History.md << EOF
## References

|[Top](#${project,,}) |
EOF

    # Create basic history-log.md
    cat > "$log_path" << EOF
# History Log

---

## Description: 

## $CURRENT_DATE

Comments by David Mullins
EOF

    # Add log entries
    for ((i=1; i<=num; i++)); do
        cat >> "$log_path" << EOF
### History Comment $i
Comments by David Mullins

#### Sub History Comment $i
EOF
    done
}

# Process options
VERBOSE=0
while getopts "hvrlun" opt; do
    case $opt in
        h) show_help; exit 0;;
        v) VERBOSE=1;;
        r|l|u) echo "Option -$opt not yet implemented"; exit 1;;
        n) ;; # Default behavior
        ?) show_help; exit 1;;
    esac
done

# Shift past the options
shift $((OPTIND-1))

# Process parameters
if [ $# -ge 1 ]; then
    PROJECT_NAME="$1"
fi

if [ $# -ge 2 ]; then
    if [[ "$2" =~ ^[0-9]+$ ]] && [ "$2" -ge 0 ] && [ "$2" -le 20 ]; then
        NUM_COMMENTS=$2
    else
        echo "Error: Number of comments must be between 0 and 20"
        exit 1
    fi
fi

if [ $# -ge 3 ]; then
    LOG_DIR="$3"
fi

# Main execution
if [ -f "History.md" ]; then
    echo "History.md already exists. Use -u to update (not implemented yet) or remove existing file first."
    exit 1
else
    [ $VERBOSE -eq 1 ] && echo "Creating History.md for '$PROJECT_NAME' with $NUM_COMMENTS comments..."
    create_history "$PROJECT_NAME" "$NUM_COMMENTS" "$LOG_DIR"
    [ $VERBOSE -eq 1 ] && echo "History.md and $LOG_DIR created successfully."
fi