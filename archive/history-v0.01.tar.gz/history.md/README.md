# Project History Template

## Version

0.0.1

## Description

A bash script to generate a [history.md](template/history.md) document from a project ".env" file or create it , if it does not exist using a basic 
`gernerate_history.sh <project_name>` with options and (optional parameters)

Here's a solution that implements the initial generation functionality:

## Installation
To use this script:

1. Save it as `generate_history.sh`
2. Make it executable: `chmod +x generate_history.sh¸`
3. Run it with an example: ``./generate_history.sh "project name" 3`

## Features

This script will:

- Create a History.md file with 3 comments following your template structure
- Create a corresponding logs/history-log.md file
- Use the current date (April 10, 2025) for all entries
- Handle the basic navigation links and structure as shown in your example
- Create necessary directories for the log file

The output will match your example structure with:

- Project header
- 3 comment sections numbered 1-3
- Proper navigation links
- References section
- A basic history-log.md file with corresponding entries

Current features:

- -h shows help
- -v enables verbose output
- Handles all three parameters (project name, number of comments, log file path)
- Validates number of comments (0-20)
- Creates directory structure if needed

Not yet implemented (but included in options for future expansion):

- -r (read history)
- -l (read log)
- -u (update existing file)
- Adding comments to existing file
- Date updating functionality

The script checks if  [history.md](template/history.md) and [history-logs.md](template/log/history-logs.md)  exists and won't overwrite it (future -u option will handle updates). To generate a new file, remove any existing [history.md](template/history.md) first.

This provides a solid foundation that matches your `generate_history.sh` "project name" 3 example output, with room to add the additional functionality you mentioned (updating dates, adding comments) in future iterations.



## Todo

If the [history.md](template/history.md) exists then there should be other function  

1) to ADD  more template comments under the last before the "References" subheading. if a comment number is provided as the 2nd Parameter, then the accounting to the Number of blank comments defaults to 1 or is optional to max 20. 
2) Update the dates of the given Parameter number in both the [history.md](template/history.md) and [history-logs.md](template/log/history-logs.md) (however this functionality will be detailed and implemented later. 

- The [history-logs.md](template/log/history-logs.md) is linked from each comment date of entry 

-  Heading is "# History Log" and its subheadings are "# \<date of entry or change> to match the entry in the main [history.md](template/history.md)  file 

  - more later

- The starting point it focused on the initial script to generate one or more "comments" customised to the serialise structure of the document, created by using the `generate_history.sh` script. The [history.md](template/history.md) is the desired output of  

  ```bash
  gernerate_history.sh "project name" 3
  ```

  

